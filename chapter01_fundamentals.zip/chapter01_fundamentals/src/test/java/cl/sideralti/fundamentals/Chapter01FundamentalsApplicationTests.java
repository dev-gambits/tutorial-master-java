package cl.sideralti.fundamentals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter01FundamentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
